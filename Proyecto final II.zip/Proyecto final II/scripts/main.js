// Animations
AOS.init({
  anchorPlacement: 'top-left',
  duration: 1000
});

